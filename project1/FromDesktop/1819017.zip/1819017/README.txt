NAME: Shan Lin
ID: 1819017

System Calls:
access
arch_prctl
brk
clone
close
execve
exit_group
fcntl
fstat
getdents
geteuid
getpid
getppid
mmap
mprotect
munmap
open
openat
read
rt_sigaction
rt_sigreturn
stat
wait4
write

Typedefs:
SIGCHLD
