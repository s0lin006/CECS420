NAME: SHAN LIN
ID: 1819017

I did not manage to fully implement the project as described. 
Child creation and multi-threading was implemented as well as file locking. 
The only thing that wasn't implemented is the bounded buffer. 
I cant seem to get the linked list working properly. 
I will continue to work on it, but if due date come around and it's still 
not fixed, this line will still be the readme file.
