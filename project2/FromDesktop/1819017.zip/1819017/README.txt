NAME: SHAN LIN
ID: 1819017

I did not manage to fully implement the project as described. Child creation 
was fully implemented without too much issue. Message queues were partially 
used. I managed to send a message from the client to the server, but had 
trouble sending a message from the server back to the client. The only thing 
that wasn't implemented was multi-threading.
