Name:   Shan Lin
ID:     1819017

I did not completely implement the project as described. The parts I did 
implement are the message queues. The message queue was working fairly well. 
The parts I did not implement are the child creation and multi-threading. The 
program seems to crash whenever I try to implement fork().
